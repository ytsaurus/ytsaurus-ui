# LogsPanel

`LogsPanel` — это компонент для отображения и работы с логами в виде виртуализированного списка. Поддерживает поиск, фильтрацию, настройки отображения и различные режимы просмотра.

## Основные возможности

- **Виртуализированный список** — эффективное отображение больших объемов данных
- **Поиск по содержимому** — с подсветкой найденных фрагментов
- **Фильтрация логов** — по имени и уровню (ERROR, INFO, DEBUG)
- **Временной диапазон** — выбор периода для отображения логов
- **Контекстный просмотр** — детальный анализ выбранного лога
- **Настройки отображения** — перенос строк, отображение ссылок, регистронезависимый поиск
- **Навигация** — быстрый переход к началу или концу логов

## Использование

### Базовый пример

```tsx
import { LogsPanel, TLogsPanelEntry, ELogsPanelLevel } from '@yandex-data-ui/dynamic-logs-viewer';

const logEntries: TLogsPanelEntry[] = [
  {
    id: '1',
    timestamp: '2023-12-01T10:00:00Z',
    displayTimestamp: '10:00:00',
    content: 'Application started successfully'
  },
  {
    id: '2',
    timestamp: '2023-12-01T10:01:00Z',
    displayTimestamp: '10:01:00',
    content: 'Error: Database connection failed'
  }
];

function MyComponent() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLogIds, setSelectedLogIds] = useState<string[]>([]);
  const [timeRange, setTimeRange] = useState(null);
  const [settings, setSettings] = useState({
    wrapLines: true,
    renderLinks: true,
    caseInsensitiveSearch: true
  });

  return (
    <LogsPanel
      searchQuery={searchQuery}
      setSearchQuery={setSearchQuery}
      settings={settings}
      onSettingsChange={setSettings}
      logsSelectorOptions={[
        { value: 'app-logs', content: 'Application Logs', data: { logName: 'app' } }
      ]}
      logsSelectorSelectedIds={selectedLogIds}
      onLogsSelectorSelectedIdsChange={setSelectedLogIds}
      timeRange={timeRange}
      onTimeRangeChange={setTimeRange}
      loading={false}
      logItemsList={logEntries}
      loadLogsAbove={async () => {}}
      loadLogsBelow={async () => {}}
      loadLogsFromHead={async () => {}}
      loadLogsFromTail={async () => {}}
      loadLogsAroundTargetLog={async () => {}}
      updateListWithLastResults={() => {}}
      getLogListItemLevel={() => ELogsPanelLevel.INFO}
      getLogListItemName={(item) => item.id}
    />
  );
}
```

### С пользовательскими метаданными

```tsx
interface CustomMeta {
  userId: string;
  sessionId: string;
}

const customLogEntries: TLogsPanelEntry<CustomMeta>[] = [
  {
    id: '1',
    timestamp: '2023-12-01T10:00:00Z',
    displayTimestamp: '10:00:00',
    content: 'User logged in',
    meta: {
      userId: 'user123',
      sessionId: 'session456'
    }
  }
];

<LogsPanel<CustomMeta>
  // ... остальные пропсы
  logItemsList={customLogEntries}
  getLogListItemLevel={(item) => 
    item.content.includes('Error') ? ELogsPanelLevel.ERROR : ELogsPanelLevel.INFO
  }
/>
```

## Режимы отображения

`LogsPanel` поддерживает несколько режимов работы:

- `NORMAL` — обычное отображение всех логов
- `SEARCH` — режим поиска с фильтрацией результатов
- `CONTEXT` — контекстный режим для детального анализа
- `MEMO_SEARCH` — сохраненные результаты поиска

## Настройки

Компонент поддерживает следующие настройки отображения:

```tsx
const settings: TLogsPanelSettings = {
  wrapLines: true,              // Перенос длинных строк
  renderLinks: true,            // Преобразование URL в ссылки
  caseInsensitiveSearch: true   // Регистронезависимый поиск
};
```

## Управление извне

Компонент предоставляет методы для внешнего управления:

```tsx
const logsRef = useRef<TLogsPanelRef>(null);

// Прокрутка к определенному элементу
logsRef.current?.scrollToItem(10, 'center');

// Получение текущего направления скролла
console.log(logsRef.current?.currentUserScrollDirection);

// Получение текущего режима отображения
console.log(logsRef.current?.viewMode);
```

## Свойства

### TLogsPanelProps

| Имя | Описание | Тип | Обязательный |
|-----|----------|-----|--------------|
| `searchQuery` | Текущий поисковый запрос | `string` | ✓ |
| `setSearchQuery` | Функция для обновления поискового запроса | `(query: string) => void` | ✓ |
| `settings` | Настройки отображения | `Partial<TLogsPanelSettings>` | |
| `onSettingsChange` | Обработчик изменения настроек | `(settings: TLogsPanelSettings) => void` | ✓ |
| `logsSelectorOptions` | Опции для выбора логов | `TLogsPanelSelectOption[]` | ✓ |
| `logsSelectorSelectedIds` | Выбранные ID логов | `string[]` | ✓ |
| `onLogsSelectorSelectedIdsChange` | Обработчик изменения выбранных логов | `(ids: string[]) => void` | ✓ |
| `timeRange` | Временной диапазон | `RelativeRangeDatePickerValue \| null` | ✓ |
| `onTimeRangeChange` | Обработчик изменения временного диапазона | `(range: RelativeRangeDatePickerValue \| null) => void` | ✓ |
| `loading` | Состояние загрузки | `boolean` | ✓ |
| `logItemsList` | Список элементов логов | `(TLogsPanelEntry<TMeta> \| TLogsPanelListLoadingItem)[]` | ✓ |
| `loadLogsAbove` | Загрузка логов выше | `() => Promise<void>` | ✓ |
| `loadLogsBelow` | Загрузка логов ниже | `() => Promise<void>` | ✓ |
| `loadLogsFromHead` | Загрузка с начала | `() => Promise<void>` | ✓ |
| `loadLogsFromTail` | Загрузка с конца | `() => Promise<void>` | ✓ |
| `getLogListItemLevel` | Функция определения уровня лога | `(item: TLogsPanelEntry<TMeta>) => ELogsPanelLevel` | ✓ |
| `getLogListItemName` | Функция получения имени лога | `(item: TLogsPanelEntry<TMeta>) => string` | ✓ |
| `getLogListItemUrl` | Функция получения URL лога | `(item: TLogsPanelEntry<TMeta>) => string` | |
| `errorMessage` | Сообщение об ошибке | `string` | |
| `className` | CSS класс | `string` | |

### TLogsPanelEntry

| Поле | Описание | Тип |
|------|----------|-----|
| `id` | Уникальный идентификатор | `string` |
| `timestamp` | Временная метка | `string` |
| `displayTimestamp` | Отображаемое время | `string` |
| `content` | Содержимое лога | `string` |
| `meta` | Дополнительные метаданные | `TMeta` |

### ELogsPanelLevel

Уровни логов:
- `DEBUG` — отладочная информация
- `INFO` — информационные сообщения  
- `ERROR` — ошибки

## Кто может помочь

По вопросам использования компонента обращайтесь к [этим разработчикам](https://staff.yandex-team.ru/departments/yandex_search_tech_searchinfradev_fml_gpu_4733/).